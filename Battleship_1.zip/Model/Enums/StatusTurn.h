#pragma once

enum StatusTurn {
	UnknownTurn,
	Past,
	Hit
};
