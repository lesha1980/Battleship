#pragma once

class StrategyRandomShot: public StrategyGame {

public:
	CoordXY Strategy();

	virtual ~StrategyRandomShot() {

	}
};
