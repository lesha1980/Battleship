#pragma once

class Screen {

public:
	void printScreenGamer_1(GameBoard& gb_1, GameBoard& gb_2, Ship** ships_1, Ship** ships_2);
	void printScreenGamer_2(GameBoard& gb_1, GameBoard& gb_2, Ship** ships_1, Ship** ships_2);
	void printScreen(GameBoard& gb_1, GameBoard& gb_2, Ship** ships_1, Ship** ships_2);
};
