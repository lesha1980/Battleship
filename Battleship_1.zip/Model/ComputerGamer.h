#pragma once

class ComputerGamer : public Gamer 
{

public:
	ComputerGamer(string login);

	virtual ~ComputerGamer() {

	}
};