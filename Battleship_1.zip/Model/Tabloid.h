#pragma once

class Tabloid {


};
