#pragma once

enum TypeShip {
	UnknownShip,
	SingleDeckShip,
	DoubleDeckShip,
	ThreeDeckShip,
	FourDeckShip
};
