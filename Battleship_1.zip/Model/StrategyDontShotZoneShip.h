#pragma once

class StrategyDontShotZoneShip:public StrategyGame {

public: 
	CoordXY Strategy();

	virtual ~StrategyDontShotZoneShip() {

	}
};
