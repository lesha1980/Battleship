#pragma once

class HumanGamer:public Gamer 
{
public:
	HumanGamer(string login);

	virtual ~HumanGamer() {

	}
};
