#include "../libs.h"

void StrategyGame::setTurns(BattleStack<Turn> turns)
{
	this->_turns = turns;
}
