#pragma once

enum StatusShip {
	UnknownStatus,
	Alive,
	Wounded,
	Dead
};
