#include "../libs.h"

HumanGamer::HumanGamer(string login):Gamer(login)
{
	
}
