#include "../libs.h"

GameMode::GameMode()
{
}
