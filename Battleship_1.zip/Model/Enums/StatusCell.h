#pragma once

enum StatusCell {
	UnknownCell,
	Free,
	Occupied,
	SingleShot,
	HitCell
};
