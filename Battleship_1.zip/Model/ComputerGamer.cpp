#include "../libs.h"

ComputerGamer::ComputerGamer(string login):Gamer(login)
{
	
}