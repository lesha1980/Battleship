#pragma once

class GameView {

public:
	void _human_pc_mode(string login);
	void _pc_pc_mode();
};